Arquetipos de Orientacion a Objetos
